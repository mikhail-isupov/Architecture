# Cloud

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cloudId** | **Integer** |  |  [optional]
**idClient** | **Integer** |  | 
**OS** | [**OSEnum**](#OSEnum) | Орерационная система | 
**RAM** | **Integer** |  | 
**CPU** | **Integer** |  | 
**HDD** | **Integer** |  | 

<a name="OSEnum"></a>
## Enum: OSEnum
Name | Value
---- | -----
WINDOWS | &quot;Windows&quot;
LINUX | &quot;Linux&quot;
