# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **Integer** |  | 
**name** | **String** |  | 
**email** | **String** |  | 
**passwordHash** | **String** |  | 
